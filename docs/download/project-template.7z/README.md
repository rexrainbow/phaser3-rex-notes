## Prepare

1.  install [node.js](https://nodejs.org/en/)
2.  Click `install.bat`
    -   `npm install`


## Preview

1.  Click `/src/projects/MYPROJ/preview.bat` in project folder, it will open application on browser

### Build

1.  Click `/src/projects/MYPROJ/build.bat`
2.  open [http server](https://chrome.google.com/webstore/detail/web-server-for-chrome/ofhbbkphhbklhfoeikjpcbhemlocgigb)
3.  Open index.html in `build` folder

## File structure

-   Folder `src` : source code folder
    -   Folder `projects`: projects
        -   Folder *MYPROJ*: A project
            -   File `preview.bat`: preview this project
                - Change command `set myproj=`+*MYPROJ*
            -   File `build.bat`: export this project to `build folder`
                - Change command `set myproj=`+*MYPROJ*
            -   File `main.js` : top file of source code
            -   Folder `scenes` : folders of scenes
            -   Folder `sprites` : folders of sprites
            -   File `index.html` : entry of application            
-   Folder `assets` : assets folder
    -   Folder *MYPROJ*: assets of a project    
-   Folder `dist` : project preview folder, created after `preview.bat`
-   Folder `build` : project export folder, created after `build.bat`
    -   File `index.html` : entry of application
    -   Folder `js` : source code
    -   Folder `assets` : assets folder