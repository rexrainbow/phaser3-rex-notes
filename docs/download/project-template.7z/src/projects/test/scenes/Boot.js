import Phaser from 'phaser'

export default class extends Phaser.Scene {
  constructor () {
    super({ key: 'BootScene' })
  }

  preload () {
    this.load.image('loaderBg', './assets/test/images/loader-bg.png')
    this.load.image('loaderBar', './assets/test/images/loader-bar.png')
  }

  create () {
    this.scene.start('SplashScene')
  }
}
